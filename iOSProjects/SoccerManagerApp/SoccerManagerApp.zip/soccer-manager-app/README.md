# soccer-manager-app
Final Project for mobile development class
